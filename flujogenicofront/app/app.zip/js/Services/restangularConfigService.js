'use strict';

flujoApp.config(function(RestangularProvider) {
	RestangularProvider.setBaseUrl('http://flujogenicoback.dev:8081');
});

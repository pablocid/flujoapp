<?php

class dstrRegionName extends Eloquent {
protected $table = 'dstr_region_name';
protected $softDelete = true;

}
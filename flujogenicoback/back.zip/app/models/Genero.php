<?php

class Genero extends Eloquent {
protected $table = 'tax_genero';
protected $softDelete = true;


}
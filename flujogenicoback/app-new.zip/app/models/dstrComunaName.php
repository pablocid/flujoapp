<?php

class dstrComunaName extends Eloquent {
protected $table = 'dstr_comuna_name';
protected $softDelete = true;

}
<?php

class NombresComunes extends Eloquent {
protected $table = 'nombre_comun';
protected $softDelete = true;

}
<?php

class FamiliaName extends Eloquent {
protected $table = 'tax_familia_src';
protected $softDelete = true;


}
<?php

class Especie extends Eloquent {
protected $table = 'tax_especie';
protected $softDelete = true;


}